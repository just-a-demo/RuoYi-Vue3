<script setup>
import { computed, ref, watch } from 'vue'
import { Repl, useStore, useVueImportMap } from '@vue/repl'
import Monaco from '@vue/repl/monaco-editor'

const props = defineProps({ modelValue: { type: String, default: '' } })
const emit = defineEmits(['update:modelValue', 'change'])
const local = path => `${import.meta.env.BASE_URL}vendor/${path}`
const defaultCode = `<script setup>\nimport { ref } from 'vue'\n\nconst count = ref(0)\nconsole.log('hello')\n<\/script>\n\n<template>\n  <button @click="count++">{{ count }}</button>\n</template>`

const { importMap, vueVersion } = useVueImportMap({
  runtimeDev: () => local('vue/vue.runtime.esm-browser.js'),
  runtimeProd: () => local('vue/vue.runtime.esm-browser.prod.js'),
  serverRenderer: () => local('vue/server-renderer.esm-browser.js'),
  vueVersion: null,
})
const template = ref({ welcomeSFC: props.modelValue || defaultCode, newSFC: '<template><div /></template>' })
const resourceLinks = computed(() => ({
  esModuleShims: local('es-module-shims/es-module-shims.wasm.js'),
  vueCompilerUrl: () => new URL('/vendor/vue/compiler-sfc.esm-browser.js', self.location.origin).href,
  typescriptLib: () => new URL('/vendor/typescript/typescript.js', self.location.origin).href,
}))
const store = useStore({ template, builtinImportMap: importMap, vueVersion, typescriptVersion: ref('5.9.2'), resourceLinks })
const content = computed({
  get: () => store.files['src/App.vue']?.code ?? '',
  set: value => { if (store.files['src/App.vue']) store.files['src/App.vue'].code = value },
})
watch(content, value => { emit('update:modelValue', value); emit('change', value) })
watch(() => props.modelValue, value => { if (value !== content.value) content.value = value })
defineExpose({ content, getValue: () => content.value, setValue: value => { content.value = value }, store })
</script>

<template>
  <div class="editor-only-root">
    <Repl :store="store" :editor="Monaco" :auto-resize="true" :show-compile-output="false" :clear-console="false" />
  </div>
</template>

<!-- 必须是全局 style。不要在非 scoped style 中使用 :deep()。 -->
<style>
*{box-sizing:border-box}html,body,#app{width:100%;height:100%;margin:0}.editor-only-root{width:100%;height:100%;overflow:hidden}
.editor-only-root .file-selector,
.editor-only-root .editor-floating,
.editor-only-root .split-pane>.right,
.editor-only-root .split-pane>.dragger,
.editor-only-root .split-pane>.toggler{display:none!important}
.editor-only-root .split-pane>.left{display:block!important;position:relative!important;width:100%!important;max-width:100%!important;flex:0 0 100%!important;z-index:1!important;pointer-events:auto!important}
.editor-only-root .editor-container{height:100%!important;width:100%!important}
.editor-only-root .vue-repl,.editor-only-root .split-pane{width:100%!important;height:100%!important}
</style>
