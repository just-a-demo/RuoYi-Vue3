import { cp, mkdir, copyFile, rm } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),out=resolve(root,'public/vendor')
await rm(out,{recursive:true,force:true});await mkdir(out,{recursive:true})
const files=[['node_modules/vue/dist/vue.runtime.esm-browser.js','vue/vue.runtime.esm-browser.js'],['node_modules/vue/dist/vue.runtime.esm-browser.prod.js','vue/vue.runtime.esm-browser.prod.js'],['node_modules/@vue/server-renderer/dist/server-renderer.esm-browser.js','vue/server-renderer.esm-browser.js'],['node_modules/@vue/compiler-sfc/dist/compiler-sfc.esm-browser.js','vue/compiler-sfc.esm-browser.js'],['node_modules/es-module-shims/dist/es-module-shims.wasm.js','es-module-shims/es-module-shims.wasm.js'],['node_modules/typescript/lib/typescript.js','typescript/typescript.js']]
for(const[from,to]of files){const target=resolve(out,to);await mkdir(dirname(target),{recursive:true});await copyFile(resolve(root,from),target)}
await cp(resolve(root,'node_modules/typescript/lib'),resolve(out,'typescript/lib'),{recursive:true})
