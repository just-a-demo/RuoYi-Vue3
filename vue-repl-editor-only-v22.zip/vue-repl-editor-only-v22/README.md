# Vue REPL 单编辑框 V22

修复 V21 的 CSS：V21 在非 scoped style 中使用了 `:deep()`，浏览器无法匹配，所以文件栏和预览没有隐藏。V22 改为全局后代选择器。

```bash
npm install
npm run dev -- --force
```

读取代码：`v-model`、`@change`、组件 ref 的 `getValue()`。
