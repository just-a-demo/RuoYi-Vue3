import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({plugins:[vue()],optimizeDeps:{exclude:['@vue/repl']},worker:{format:'es'},build:{target:'es2022',chunkSizeWarningLimit:7000}})
